# Deployment Guide for Obamax Gardens Management Software

**Target:** SecureHostify cPanel Hosting  
**Domain:** obamaxgardens.com  
**Server IP:** 107.161.174.15

---

## Prerequisites

- ✅ Hosting account created (SecureHostify)
- ✅ Control Panel access
- ✅ FTP credentials
- 📋 Database credentials (will be created in cPanel)

---

## Step 1: Prepare Your Local Project

### 1.1 Build Production Assets
Run these commands in your project root:

```bash
npm install
npm run build
```

This creates optimized production-ready assets in the `public/build` directory.

### 1.2 Generate Environment File
Ensure you have an `.env` file (copy from `.env.example`):

```bash
cp .env.example .env
php artisan key:generate
```

### 1.3 Update Composer Dependencies
```bash
composer install --optimize-autoloader --no-dev
```

---

## Step 2: Set Up Database on Hosting

**Log in to cPanel:** http://107.161.174.15:2082/
- **Username:** obamaxga
- **Password:** [Your provided password]

### 2.1 Create MySQL Database
1. Go to **cPanel → Databases → MySQL Databases**
2. Create a new database:
   - **Database Name:** `obamaxga_obamax`
   - Click "Create Database"
3. Create a new MySQL user:
   - Go to **MySQL Users**
   - **Username:** `obamaxga_user`
   - **Password:** [Create a strong password]
   - Click "Create User"
4. Assign user to database:
   - Go to **Add User to Database**
   - Select user and database
   - Check ALL privileges
   - Click "Add"

**Record these credentials - you'll need them in Step 4.**

---

## Step 3: Deploy Files via FTP

### 3.1 Connect via FTP
Use an FTP client (e.g., FileZilla, WinSCP):

```
Host: obamaxgardens.com
(Temporary: 107.161.174.15)
Username: obamaxga
Password: [Your FTP password]
```

### 3.2 Upload Project Files

Navigate to the **public_html** directory on the server.

**Create this folder structure:**
```
public_html/
├── app/
├── bootstrap/
├── config/
├── database/
├── public/
│   ├── build/          (upload the production build)
│   ├── storage/        (link to storage, created later)
│   ├── index.php
│   ├── .htaccess
│   └── robots.txt
├── resources/
├── routes/
├── storage/            (create empty - for logs, uploads)
├── vendor/
├── .env
├── .htaccess
├── artisan
├── composer.json
├── composer.lock
└── [other root files]
```

### 3.3 Upload These Critical Files/Directories
1. ✅ `app/` - Application code
2. ✅ `bootstrap/` - Bootstrap files
3. ✅ `config/` - Configuration files
4. ✅ `database/` - Migrations and seeders
5. ✅ `public/` - Public assets (entire folder)
6. ✅ `resources/` - CSS, JS, views
7. ✅ `routes/` - Route definitions
8. ✅ `vendor/` - Composer dependencies
9. ✅ `.env` - Environment variables (configure in Step 4)
10. ✅ `.htaccess` - URL rewriting
11. ✅ `artisan` - Laravel CLI
12. ✅ `composer.json` & `composer.lock`

**Skip uploading:**
- ❌ `node_modules/` (not needed; assets already built)
- ❌ `storage/logs/` (create empty folder on server)
- ❌ `tests/` (optional for production)

---

## Step 4: Configure Server Environment

### 4.1 Create/Update `.env` File

Via FTP or cPanel File Manager, create/edit `.env`:

```env
APP_NAME="Obamax Gardens Management"
APP_ENV=production
APP_DEBUG=false
APP_KEY=base64:[your-app-key-from-local]
APP_URL=http://www.obamaxgardens.com
APP_TIMEZONE=Africa/Accra

# Database (from Step 2)
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=obamaxga_obamax
DB_USERNAME=obamaxga_user
DB_PASSWORD=[Your MySQL password from Step 2]
DB_CHARSET=utf8mb4
DB_COLLATION=utf8mb4_unicode_ci

# Mail Settings (optional, configure based on your needs)
MAIL_MAILER=log
MAIL_HOST=mail.obamaxgardens.com
MAIL_PORT=587
MAIL_USERNAME=your-email@obamaxgardens.com
MAIL_PASSWORD=your-email-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@obamaxgardens.com
MAIL_FROM_NAME="${APP_NAME}"

# Session
SESSION_DRIVER=file
SESSION_DOMAIN=obamaxgardens.com

# Cache
CACHE_DRIVER=file

# Queue (if using)
QUEUE_CONNECTION=database

# Additional Settings
SANCTUM_STATEFUL_DOMAINS=obamaxgardens.com,www.obamaxgardens.com
```

**Important:** 
- Replace `[your-app-key-from-local]` with the key from your local `.env` (from `php artisan key:generate`)
- Set `APP_DEBUG=false` in production
- Update to use `https://` once SSL is configured

### 4.2 Set File Permissions via SSH (if available) or cPanel Terminal

If you have SSH access:
```bash
chmod -R 755 /home/obamaxga/public_html
chmod -R 644 /home/obamaxga/public_html/*.php
chmod -R 777 /home/obamaxga/public_html/storage
chmod -R 777 /home/obamaxga/public_html/bootstrap/cache
```

If no SSH, use cPanel File Manager:
1. Right-click on `storage/` → Properties → Change Permissions to **777**
2. Right-click on `bootstrap/cache/` → Properties → Change Permissions to **777**

### 4.3 Create `.htaccess` in public_html (if missing)

Create this file in **public_html**:

```apache
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews
    </IfModule>

    RewriteEngine On

    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [QSA,L]
</IfModule>
```

---

## Step 5: Run Database Migrations

Via SSH or cPanel Terminal:

```bash
cd /home/obamaxga/public_html
php artisan migrate --force
```

If prompted to run migrations on production, type `yes`.

**Optional:** Load seed data if you have seeders set up:
```bash
php artisan db:seed --force
```

---

## Step 6: Configure Domain (Once Propagated)

Once your domain `obamaxgardens.com` has propagated (24-48 hours):

1. **Update nameservers** (if pointing external domain):
   - Go to your domain registrar
   - Set nameservers to:
     - `ns1.securehostify.com`
     - `ns2.securehostify.com`

2. **Access your site:**
   - `http://www.obamaxgardens.com`
   - Temporary: `http://107.161.174.15/~obamaxga/`

---

## Step 7: SSL Certificate (HTTPS)

1. Log in to cPanel
2. Go to **SSL/TLS → Manage SSL sites**
3. Install a free SSL certificate (AutoSSL or Let's Encrypt)
4. Update `.env`:
```env
APP_URL=https://www.obamaxgardens.com
```

---

## Step 8: Verify Installation

Check these on your live server:

1. ✅ Visit homepage: `http://www.obamaxgardens.com`
2. ✅ Test main features
3. ✅ Check Laravel logs: `/storage/logs/laravel.log`
4. ✅ Test database connection
5. ✅ Verify file uploads work

---

## Troubleshooting

### 500 Internal Server Error
- Check `/storage/logs/laravel.log`
- Verify `.env` file exists and is readable
- Ensure `storage/` and `bootstrap/cache/` are writable (777)
- Verify PHP version is 8.2+

### Database Connection Error
- Verify DB credentials in `.env`
- Check MySQL user has proper privileges
- Ensure database exists

### Assets Not Loading (CSS/JS issues)
- Verify `public/build/` directory is uploaded
- Clear browser cache
- Check vite manifest exists: `public/build/manifest.json`

### 404 Errors on Routes
- Ensure `.htaccess` is in `public_html/`
- Verify `mod_rewrite` is enabled (ask hosting support)
- Check `.htaccess` permissions (644)

---

## Production Checklist

- [ ] `.env` configured with production values
- [ ] `APP_DEBUG=false`
- [ ] `APP_ENV=production`
- [ ] Database migrated successfully
- [ ] `storage/` and `bootstrap/cache/` are writable
- [ ] Assets built and uploaded (`public/build/`)
- [ ] SSL certificate installed
- [ ] Domain propagated
- [ ] Backups configured (ask hosting support)
- [ ] Email configured (if applicable)
- [ ] Logs monitored

---

## Next Steps After Deployment

1. **Set up automated backups** via cPanel
2. **Configure email accounts** for your domain (obamaxgardens.com)
3. **Monitor application logs** regularly
4. **Set up staging environment** for testing updates
5. **Document any custom configurations**

---

## Support Contacts

- **SecureHostify Support:** support@securehostify.com
- **Your Control Panel:** http://107.161.174.15:2082/
- **Domain:** obamaxgardens.com

---

*Last Updated: March 13, 2026*
